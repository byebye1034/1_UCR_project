# Aneuploid_embryo
Scripts for Reconstituting the single-cell transcriptome atlas of human aneuploid blastocysts
